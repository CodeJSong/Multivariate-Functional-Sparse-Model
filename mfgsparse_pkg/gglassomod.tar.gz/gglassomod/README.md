A heavily modified version of gglasso that was initiated by Yang, Y. and Zou, H. (2015). 
The features added to the original package: mixing parameter alpha with its net search crossvalidation, curvature penalizing for functional 
regression with its net search cross-validations, optimized Fortran core function to speed up the curvature penalization
updates, progress reports and time estimations. This package does not work independently from the MFSGrp package
and it does not interfere with the functions of gglasso package due to slight name differences.